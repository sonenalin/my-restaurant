import React from 'react'

export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Hello from Next.js!</h1>
      <p>This is a simple site deployed to Vercel 🚀</p>

    </main>
  )
}
