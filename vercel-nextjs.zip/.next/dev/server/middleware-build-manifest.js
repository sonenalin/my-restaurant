globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_c629999b._.js",
      "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_b0a279d5._.js",
      "static/chunks/node_modules_next_app_72f3d36f.js",
      "static/chunks/[next]_entry_page-loader_ts_742e4b53._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_7f09fef0._.js",
      "static/chunks/[root-of-the-server]__45f039c3._.js",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_c1c8acf6._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_c629999b._.js",
      "static/chunks/node_modules_next_dist_shared_lib_cf5b50a6._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_19fd0646._.js",
      "static/chunks/node_modules_next_error_1cfbb379.js",
      "static/chunks/[next]_entry_page-loader_ts_43b523b5._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_7f09fef0._.js",
      "static/chunks/[root-of-the-server]__092393de._.js",
      "static/chunks/pages__error_2da965e7._.js",
      "static/chunks/turbopack-pages__error_91f36f75._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cedd0592._.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_9212ccad._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_1dd7fb59.js",
    "static/chunks/node_modules_next_dist_compiled_a0e4c7b4._.js",
    "static/chunks/node_modules_next_dist_client_a38d7d69._.js",
    "static/chunks/node_modules_next_dist_4b2403f5._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_d80fb378._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_86f4650b._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];